"""Download free public weights onto the GPU host, never into the website repo."""
from huggingface_hub import snapshot_download
from inference import MODEL_ID, MODEL_REVISION, MODEL_PATH

snapshot_download(repo_id=MODEL_ID, revision=MODEL_REVISION, local_dir=str(MODEL_PATH))
print("Pinned model downloaded into the dedicated model volume.")
