"""Authenticated, private, bounded single-GPU generation queue."""
import asyncio
import hmac
import json
import os
import re
import shutil
import sqlite3
import threading
import time
import uuid
from contextlib import asynccontextmanager, contextmanager
from pathlib import Path
from fastapi import FastAPI, Depends, File, Form, Header, HTTPException, UploadFile, Request
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse
from core import validate_spec, safe_image, conditions
import inference

TOKEN = os.environ.get("VIDEO_API_TOKEN", "")
ROOT = Path(os.environ.get("VIDEO_DATA", "/data")).resolve()
DAY_LIMIT = int(os.environ.get("VIDEO_DAY_LIMIT", "3"))
QUEUE_LIMIT = int(os.environ.get("VIDEO_QUEUE_LIMIT", "8"))
RETENTION = int(os.environ.get("VIDEO_RETENTION_HOURS", "24")) * 3600
LOCK = threading.Lock()
STOP = threading.Event()


@contextmanager
def db():
    connection = sqlite3.connect(ROOT / "jobs.sqlite", timeout=15)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def auth(authorization: str = Header(default="")):
    if len(TOKEN) < 32 or not hmac.compare_digest(authorization, "Bearer " + TOKEN):
        raise HTTPException(401, "unauthorized")


def owner(x_studio_owner: str = Header(default=""), authenticated=Depends(auth)):
    if not re.fullmatch(r"[a-f0-9]{64}", x_studio_owner):
        raise HTTPException(401, "invalid_owner")
    return x_studio_owner


def initialize():
    if len(TOKEN) < 32:
        raise RuntimeError("Set VIDEO_API_TOKEN to a random secret of at least 32 characters")
    ROOT.mkdir(parents=True, exist_ok=True)
    with db() as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, owner TEXT, nonce TEXT, spec TEXT, status TEXT, stage TEXT, progress INTEGER, cancel INTEGER DEFAULT 0, error TEXT, result TEXT, created INTEGER, updated INTEGER, UNIQUE(owner,nonce))")
        conn.execute("UPDATE jobs SET status='failed',stage='failed',error='server_restarted' WHERE status IN ('queued','running')")


def change(job, **values):
    values["updated"] = int(time.time())
    with db() as conn:
        conn.execute("UPDATE jobs SET " + ",".join(k + "=?" for k in values) + " WHERE id=?", (*values.values(), job))


def cleanup():
    with LOCK, db() as conn:
        expired = conn.execute("SELECT id FROM jobs WHERE created<? AND status NOT IN ('queued','running')", (int(time.time()) - RETENTION,)).fetchall()
        for row in expired:
            shutil.rmtree(ROOT / row["id"], ignore_errors=True)
            conn.execute("DELETE FROM jobs WHERE id=?", (row["id"],))


def work():
    while not STOP.wait(1):
        cleanup()
        with LOCK, db() as conn:
            job = conn.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created,id LIMIT 1").fetchone()
            if not job:
                continue
            conn.execute("UPDATE jobs SET status='running',stage='loading_model',progress=1 WHERE id=?", (job["id"],))
        job_id = job["id"]
        directory = ROOT / job_id
        spec = json.loads(job["spec"])

        def cancelled():
            with db() as conn:
                row = conn.execute("SELECT cancel FROM jobs WHERE id=?", (job_id,)).fetchone()
            return STOP.is_set() or row is None or bool(row["cancel"])

        try:
            first = safe_image((directory / "first.png").read_bytes()) if (directory / "first.png").exists() else None
            last = safe_image((directory / "last.png").read_bytes()) if (directory / "last.png").exists() else None
            result = inference.generate(spec, first, last, directory / "video.mp4", lambda stage, n: change(job_id, stage=stage, progress=n), cancelled)
            with LOCK, db() as conn:
                row = conn.execute("SELECT cancel FROM jobs WHERE id=?", (job_id,)).fetchone()
                if not row or row["cancel"]:
                    (directory / "video.mp4").unlink(missing_ok=True)
                    conn.execute("UPDATE jobs SET status='cancelled',stage='cancelled' WHERE id=?", (job_id,))
                else:
                    conn.execute("UPDATE jobs SET status='completed',stage='completed',progress=100,result=?,updated=? WHERE id=?", (json.dumps(result), int(time.time()), job_id))
        except inference.Cancelled:
            change(job_id, status="cancelled", stage="cancelled")
        except Exception as error:
            (directory / "video.mp4").unlink(missing_ok=True)
            code = "gpu_memory" if "out of memory" in str(error).lower() else "generation_failed"
            change(job_id, status="failed", stage="failed", error=code)
        finally:
            # Uploaded references are needed only for this job, not kept as a public library.
            for filename in ("first.png", "last.png"):
                (directory / filename).unlink(missing_ok=True)


@asynccontextmanager
async def lifespan(app):
    initialize()
    STOP.clear()
    thread = threading.Thread(target=work, daemon=True)
    thread.start()
    yield
    STOP.set()
    thread.join(timeout=2)


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


@app.middleware("http")
async def reject_before_upload(request: Request, call_next):
    if len(TOKEN) < 32 or not hmac.compare_digest(request.headers.get("authorization", ""), "Bearer " + TOKEN):
        return JSONResponse({"detail": "unauthorized"}, status_code=401)
    try:
        size = int(request.headers.get("content-length", "0"))
    except ValueError:
        return JSONResponse({"detail": "invalid_request"}, status_code=400)
    if size > 22000000:
        return JSONResponse({"detail": "upload_limit"}, status_code=413)
    return await call_next(request)


def public(row):
    data = dict(row)
    for key in ("owner", "nonce", "cancel"):
        data.pop(key, None)
    data["spec"] = json.loads(data["spec"])
    data["result"] = json.loads(data["result"]) if data["result"] else None
    return data


@app.get("/v1/capabilities", dependencies=[Depends(auth)])
def capabilities():
    return {**inference.readiness(), "model": inference.MODEL_ID, "revision": inference.MODEL_REVISION,
            "modes": ["text", "image", "frames"], "fps": 16, "durations": [3, 5], "dayLimit": DAY_LIMIT,
            "retentionHours": RETENTION // 3600, "audio": False}


@app.get("/v1/jobs")
def history(identity=Depends(owner)):
    with db() as conn:
        rows = conn.execute("SELECT * FROM jobs WHERE owner=? ORDER BY created DESC LIMIT 20", (identity,)).fetchall()
    return {"jobs": [public(row) for row in rows]}


@app.post("/v1/jobs")
async def create(spec: str = Form(...), nonce: str = Form(...), first: UploadFile | None = File(default=None), last: UploadFile | None = File(default=None), identity=Depends(owner)):
    if len(spec) > 16000 or not re.fullmatch(r"[a-f0-9-]{16,64}", nonce):
        raise HTTPException(422, "invalid_request")
    try:
        validated = validate_spec(json.loads(spec))
        images = []
        for image in (first, last):
            images.append(safe_image(await image.read(10 * 1024 * 1024 + 1)) if image else None)
        if validated["mode"] == "text" and any(image is not None for image in images):
            raise ValueError("text_has_images")
        if validated["mode"] != "text" and images[0] is None:
            raise ValueError("missing_frame")
        if validated["mode"] == "frames" and images[1] is None:
            raise ValueError("missing_frame")
        if validated["mode"] == "image" and images[1] is not None:
            raise ValueError("unexpected_last_frame")
    except (ValueError, OSError, ImageError) as error:
        raise HTTPException(422, "invalid_input") from error
    with LOCK, db() as conn:
        prior = conn.execute("SELECT * FROM jobs WHERE owner=? AND nonce=?", (identity, nonce)).fetchone()
        if prior:
            return public(prior)
        if not inference.readiness()["ready"]:
            raise HTTPException(503, inference.readiness()["reason"])
        if conn.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0] >= QUEUE_LIMIT:
            raise HTTPException(429, "queue_full")
        if conn.execute("SELECT COUNT(*) FROM jobs WHERE owner=? AND status IN ('queued','running')", (identity,)).fetchone()[0]:
            raise HTTPException(409, "job_already_active")
        if conn.execute("SELECT COUNT(*) FROM jobs WHERE owner=? AND created>?", (identity, int(time.time()) - 86400)).fetchone()[0] >= DAY_LIMIT:
            raise HTTPException(429, "daily_limit")
        job_id = uuid.uuid4().hex
        directory = ROOT / job_id
        directory.mkdir()
        try:
            for name, image in zip(("first.png", "last.png"), images):
                if image:
                    image.save(directory / name, "PNG")
            now = int(time.time())
            conn.execute("INSERT INTO jobs(id,owner,nonce,spec,status,stage,progress,created,updated) VALUES(?,?,?,?,?,?,?,?,?)", (job_id, identity, nonce, json.dumps(validated), "queued", "queued", 0, now, now))
            row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        except Exception:
            shutil.rmtree(directory, ignore_errors=True)
            raise
    return public(row)


# Pillow rejects corrupt images with OSError or its dedicated bomb exception.
from PIL.Image import DecompressionBombError as ImageError


def owned(job_id, identity):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        raise HTTPException(404, "not_found")
    with db() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id=? AND owner=?", (job_id, identity)).fetchone()
    if not row:
        raise HTTPException(404, "not_found")
    return row


@app.get("/v1/jobs/{job_id}")
def status(job_id: str, identity=Depends(owner)):
    return public(owned(job_id, identity))


@app.post("/v1/jobs/{job_id}/cancel")
def cancel(job_id: str, identity=Depends(owner)):
    with LOCK:
        row = owned(job_id, identity)
        if row["status"] == "queued":
            change(job_id, cancel=1, status="cancelled", stage="cancelled")
            shutil.rmtree(ROOT / job_id, ignore_errors=True)
        elif row["status"] == "running":
            change(job_id, cancel=1, stage="cancelling")
    return public(owned(job_id, identity))


@app.get("/v1/jobs/{job_id}/video")
def video(job_id: str, identity=Depends(owner)):
    row = owned(job_id, identity)
    path = ROOT / job_id / "video.mp4"
    if row["status"] != "completed" or not path.is_file():
        raise HTTPException(409, "video_not_ready")
    return FileResponse(path, media_type="video/mp4", headers={"Cache-Control": "private, no-store"})
