"""No model download, account creation or spending: only hardware checks."""
import json
import shutil
from inference import readiness, MODEL_ID, MODEL_REVISION

report = {**readiness(), "model": MODEL_ID, "revision": MODEL_REVISION, "ffmpeg": bool(shutil.which("ffmpeg"))}
try:
    import torch
    if torch.cuda.is_available():
        report["gpuName"] = torch.cuda.get_device_name(0)
        report["vramGB"] = round(torch.cuda.get_device_properties(0).total_memory / 1024**3, 1)
except ImportError:
    pass
print(json.dumps(report, indent=2))
raise SystemExit(0 if report["ready"] and report["ffmpeg"] else 1)
