"""Actual local Wan inference. There is no demonstration or resize fallback."""
import os
from pathlib import Path
from core import conditions

MODEL_ID = "Wan-AI/Wan2.1-VACE-1.3B-diffusers"
MODEL_REVISION = "ec4d2cb062b548996b179d493fdd05340de702a1"
MODEL_PATH = Path(os.environ.get("MODEL_PATH", "/models/wan-vace"))
_pipeline = None


class Cancelled(Exception):
    pass


def readiness():
    try:
        import torch
        gpu = bool(torch.cuda.is_available())
    except ImportError:
        gpu = False
    installed = (MODEL_PATH / "model_index.json").is_file()
    return {"ready": gpu and installed, "gpu": gpu, "weights": installed,
            "reason": None if gpu and installed else "gpu_required" if not gpu else "weights_required"}


def generate(spec, first, last, destination, progress, cancelled):
    global _pipeline
    import torch
    import numpy as np
    from diffusers import AutoencoderKLWan, WanVACEPipeline
    from diffusers.utils import export_to_video
    if not readiness()["ready"]:
        raise RuntimeError(readiness()["reason"])
    if cancelled():
        raise Cancelled()
    if _pipeline is None:
        progress("loading_model", 1)
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        vae = AutoencoderKLWan.from_pretrained(str(MODEL_PATH), subfolder="vae", torch_dtype=torch.float32, local_files_only=True)
        _pipeline = WanVACEPipeline.from_pretrained(str(MODEL_PATH), vae=vae, torch_dtype=dtype, local_files_only=True)
        _pipeline.enable_model_cpu_offload()
        _pipeline.vae.enable_tiling()
        _pipeline.set_progress_bar_config(disable=True)
    video, masks, start, end, count, width, height = conditions(spec, first, last)
    steps = {"draft": 20, "standard": 32, "detailed": 50}[spec["quality"]]

    def callback(pipe, step, timestep, values):
        if cancelled():
            raise Cancelled()
        progress("denoising", min(95, 5 + round(90 * (step + 1) / steps)))
        return values

    progress("encoding_prompt", 3)
    frames = _pipeline(prompt=spec["prompt"], negative_prompt=spec["negative"], video=video, mask=masks,
                       height=height, width=width, num_frames=count, num_inference_steps=steps,
                       guidance_scale=5.0, conditioning_scale=1.0,
                       generator=torch.Generator(device="cpu").manual_seed(spec["seed"]),
                       callback_on_step_end=callback).frames[0]
    if cancelled():
        raise Cancelled()
    if spec["anchors"]:
        if start is not None:
            frames[0] = np.asarray(start, dtype=np.float32) / 255
        if end is not None:
            frames[-1] = np.asarray(end, dtype=np.float32) / 255
    progress("encoding_video", 98)
    export_to_video(frames, str(destination), fps=16)
    if cancelled():
        destination.unlink(missing_ok=True)
        raise Cancelled()
    torch.cuda.empty_cache()
    return {"width": width, "height": height, "frames": count, "fps": 16, "seed": spec["seed"], "silent": True}
