"""Model-independent job contract and native frame conditioning."""
import io
import secrets
from PIL import Image, ImageOps

PROFILES = {"landscape": (832, 480), "portrait": (480, 832), "square": (624, 624)}
STEPS = {"draft": 20, "standard": 32, "detailed": 50}
MODES = {"text", "image", "frames"}


def validate_spec(value):
    if not isinstance(value, dict):
        raise ValueError("invalid_spec")
    mode = value.get("mode", "text")
    ratio = value.get("ratio", "landscape")
    quality = value.get("quality", "standard")
    duration = value.get("duration", 5)
    prompt = value.get("prompt", "")
    negative = value.get("negative", "")
    if not isinstance(mode, str) or not isinstance(ratio, str) or not isinstance(quality, str) or mode not in MODES or ratio not in PROFILES or quality not in STEPS:
        raise ValueError("invalid_settings")
    if not isinstance(duration, int) or duration not in (3, 5) or isinstance(duration, bool):
        raise ValueError("invalid_duration")
    if not isinstance(prompt, str) or not 5 <= len(prompt.strip()) <= 2400:
        raise ValueError("invalid_prompt")
    if not isinstance(negative, str) or len(negative) > 600:
        raise ValueError("invalid_negative_prompt")
    seed = value.get("seed")
    if seed is None:
        seed = secrets.randbelow(2147483648)
    if not isinstance(seed, int) or isinstance(seed, bool) or not 0 <= seed <= 2147483647:
        raise ValueError("invalid_seed")
    title = value.get("title", "Untitled film")
    if not isinstance(title, str) or len(title) > 80:
        raise ValueError("invalid_title")
    if "anchors" in value and not isinstance(value["anchors"], bool):
        raise ValueError("invalid_anchors")
    return {"mode": mode, "ratio": ratio, "quality": quality, "duration": duration,
            "prompt": prompt.strip(), "negative": negative, "seed": seed,
            "title": title, "anchors": value.get("anchors") is not False}


def safe_image(data):
    if not data or len(data) > 10 * 1024 * 1024:
        raise ValueError("image_size")
    with Image.open(io.BytesIO(data)) as image:
        if image.format not in ("PNG", "JPEG", "WEBP") or image.width * image.height > 16000000:
            raise ValueError("image_format")
        image.load()
        image = ImageOps.exif_transpose(image).convert("RGBA")
        matte = Image.new("RGBA", image.size, "white")
        matte.alpha_composite(image)
        return matte.convert("RGB")


def conditions(spec, first=None, last=None):
    """VACE black mask keeps a frame; white mask generates the unknown frames."""
    width, height = PROFILES[spec["ratio"]]
    count = spec["duration"] * 16 + 1  # Wan's temporal constraint: 4n+1.
    if spec["mode"] == "text":
        if first is not None or last is not None:
            raise ValueError("text_has_images")
        return None, None, None, None, count, width, height
    if first is None or (spec["mode"] == "frames" and last is None):
        raise ValueError("missing_frame")
    if spec["mode"] == "image" and last is not None:
        raise ValueError("unexpected_last_frame")
    first = ImageOps.fit(first, (width, height), method=Image.Resampling.LANCZOS)
    last = ImageOps.fit(last, (width, height), method=Image.Resampling.LANCZOS) if last else None
    video = [Image.new("RGB", (width, height), "black") for _ in range(count)]
    masks = [Image.new("RGB", (width, height), "white") for _ in range(count)]
    video[0], masks[0] = first, Image.new("RGB", (width, height), "black")
    if last:
        video[-1], masks[-1] = last, Image.new("RGB", (width, height), "black")
    return video, masks, first, last, count, width, height
