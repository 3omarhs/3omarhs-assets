# Video Studio — self-hosted deployment

The public PHP workspace is `/services/video-studio/`. Neural generation runs on a separate server you control. This package uses the Apache-2.0 Wan VACE 1.3B model and free/open-source libraries. No paid inference service, trial balance, provider web scraping or third-party account is used. Hardware, electricity and hosting are not guaranteed free. There is no GPU server provisioned by this release.

## GPU host

Use a Linux NVIDIA machine with Docker Compose supporting `gpus: all` and the NVIDIA Container Toolkit. Plan for 24 GB VRAM, 64 GB system RAM and at least 80 GB free disk; this is a conservative deployment target, not a measured minimum for every profile. A shared PHP web host cannot run this model. The development computer has Intel Iris Xe, so real CUDA inference could not be exercised here.

Point a hostname you own at the GPU server. Open ports 80/443 for Caddy HTTPS; do not publish port 8080 directly. The API requires a bearer secret before parsing uploads. Its owner header is derived server-side by the PHP gateway. Public visitors never receive this secret.

Copy the contents of `backend/` to the GPU host. Then:

```sh
cp env.example .env
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
# Set GPU_DOMAIN and VIDEO_API_TOKEN in .env. Keep this file private.
docker compose build
docker compose run --rm gpu python prepare_models.py
docker compose run --rm gpu python doctor.py
docker compose up -d
```

`prepare_models.py` downloads the free public model snapshot `Wan-AI/Wan2.1-VACE-1.3B-diffusers`, revision `ec4d2cb062b548996b179d493fdd05340de702a1`, into a dedicated model volume. No model weight, reference image, generated clip or credential is stored in the website source repository. Downloading the model is a large download; generation never calls a hosted inference API. The pipeline loads local files only.

## Website host

In the existing private `.env.3omarhs` file outside `public_html`, set:

```text
VIDEO_STUDIO_URL=https://video-gpu.your-domain.example
VIDEO_STUDIO_TOKEN=<same random secret as VIDEO_API_TOKEN>
```

Do not include a username, password, query or fragment in the URL. Production requires HTTPS with a valid certificate; HTTP is accepted only in a non-production environment for local contract tests. Enable PHP cURL and fileinfo. Configure PHP `upload_max_filesize=12M` and `post_max_size=24M`; both reference images together are capped at 20 MB, and the gateway rejects total requests above 22 MB. The API job submission returns immediately; generation occurs in the GPU worker.

Open the studio and click **Check connection**. The Generate button becomes available only after the backend reports CUDA and installed weights. No placeholder video is returned when the backend is unavailable. Readiness errors distinguish missing setup, authentication, GPU and model files. A completed neural inference is required before enabling playback/download.

## Inputs and outputs

- Text: free text plus explicit style/camera instructions; no external prompt rewrite service.
- Image: first-frame conditioning with unknown frames masked for generation.
- First/last: both endpoint frames condition Wan VACE. The exact-endpoint option replaces only the first/last decoded frames with the cropped input images; intermediate motion comes from the neural model. Natural motion and subject consistency are model-dependent.
- Ratios: 832x480 landscape, 480x832 portrait, 624x624 square. These native dimensions are slightly different from nominal 16:9/9:16 to satisfy model alignment constraints.
- Lengths: 49/81 frames at 16 FPS (approximately 3/5 seconds). Draft/Standard/Detailed use 20/32/50 denoising steps. Output is silent MP4; no audio model is claimed.
- Fixed seeds are recorded with results. Uploaded images are center-cropped to the selected ratio; the canvas input preview shows this same crop. PNG/JPEG/WebP are accepted, up to 10 MB and 16 MP per reference.

## Operations and privacy

A single inference thread serializes the GPU pipeline. SQLite stores job ownership, progress and metadata. Default limits are three submitted takes per owner per rolling 24 hours, one active take per owner and eight globally pending/running jobs. Set `VIDEO_DAY_LIMIT`/`VIDEO_QUEUE_LIMIT` to adjust GPU usage. The gateway also limits mutations per session. This is not a paid credit system.

Job IDs alone do not grant access. List/status/cancel/video calls require the website session and the matching owner at the GPU server. Video streaming supports single HTTP byte ranges. CSRF and same-origin checks protect submissions/cancellations. Cancellation is cooperative at the next denoising callback; a cancelled output is discarded, including a cancellation that races encoding completion. Restarted active jobs fail explicitly rather than returning false success. A repeated idempotency nonce returns the original job without duplicating GPU work.

Results expire after 24 hours by default; the worker deletes expired metadata and output folders. Input images are removed after each attempted generation. Projects downloaded from the browser include prompt settings and reference images; project data is not automatically uploaded, sent to alternatives or persisted in localStorage. Generated results belong to the browser session: download them before losing the session or retention window. The entire workspace is excluded from the website agent's data collection.

## Free alternatives

The optional bottom-of-page links are verified ongoing free web plans: ZSky, Vivago, MindVideo, Arena, Qwen, Steve AI, HeyGen and Invideo. Their usage limits, branding and licenses differ and can change. These links do not provide API inference for this portal. D-ID/Pictory/Deevid trials and unverified ongoing free video offers are excluded. Source links and the verification date are shown beside the plans. “Ongoing free” is not a guarantee that any third-party company will retain its policy forever.

## Verification boundary

CPU tests cover input validation, frame masks and dimensions, endpoint preservation contract, API authentication, ownership isolation, queue idempotency, limits, cancellation, private downloads and readiness. Browser checks cover modes, cropping, project save/load, validation, responsive Arabic/English layout and the real unconfigured state. A test-only inference stub may be used by the unit suite to exercise queue transitions; it is not included in the production execution path and its output is not represented as AI footage.

CUDA image quality, timing, memory consumption and codec output must still be verified on the eventual GPU server. This release cannot honestly claim a real generated video without that hardware. Use a short Draft take first, then test both reference modes before opening the service to the public.

Sources: https://github.com/ali-vilab/VACE · https://huggingface.co/Wan-AI/Wan2.1-VACE-1.3B-diffusers · https://huggingface.co/docs/diffusers/v0.36.0/api/pipelines/wan
