# Interface Library / 3omar.hs

20 original standalone HTML templates and all 25 Agent Elements registry items. This is NOT the entire 21st.dev marketplace.

HTML: open any file under html-templates. Edit the HTML/CSS and connect your own forms/backend. All data and prices in the examples are placeholders.

React: install a registry JSON into an existing React + Tailwind v4 project with npx shadcn@latest add ./registry/NAME.json. Original dependencies are pinned; Next dynamic is included where required. Import components/agent-elements/agent-ui.css into your global stylesheet. The extracted react-source directory is also included for manual use. Connect your own AI endpoint; no API key or live AI service is provided.

Agent Elements copyright (c) 2026 21st.dev, MIT. Pinned source b04b36cb6381a1dd1a0e86cc7c90564ddcd56d37: https://github.com/21st-dev/agent-elements . Preserve its license. Original HTML templates by 3omar.hs, MIT (separate license included).
